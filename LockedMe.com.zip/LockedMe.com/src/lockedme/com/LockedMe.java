package lockedme.com;

import java.util.InputMismatchException;
import java.util.Scanner;

public class LockedMe {

	public static void main(String[] args) {
		
		Scanner s = new Scanner(System.in);
		AddFile addFile = new AddFile();
		DeleteFile deleteFile = new DeleteFile();
		ShowFileNames showFileNames = new ShowFileNames();
		SearchFile searchFile = new SearchFile();
		
		System.out.println("Welcome to LockedMe.com");
		System.out.println("Developed by Faisal Almusallam, Email: faisal.almusallam408@gmail.com");
		System.out.println("==========================================================");
		
		int choiceInMainMenu;
		try {
		do {
			System.out.println("============================");
			System.out.println("Please choose from below options:");
			System.out.println("[1] Show files.");
			System.out.println("[2] Add, delete, or search for a file.");
			System.out.println("[3] Exit");
			System.out.print("Enter your choice: ");
			choiceInMainMenu = s.nextInt();
			
			switch(choiceInMainMenu) {
				case 1: 
					System.out.println();
					System.out.println("Files in the directory are: ");
					showFileNames.getFileNames();
				break;
				
				case 2:
					String fileName;
					int choiceInOperationsMenu;
					do {
						System.out.println("============================");
						System.out.println("Please choose the operation you want to perform:");
						System.out.println("[1] Add a file.");
						System.out.println("[2] Delete a file.");
						System.out.println("[3] Search for a file.");
						System.out.println("[4] Return to main menu.");
						System.out.print("Enter your choice: ");
						choiceInOperationsMenu = s.nextInt();
						
						switch(choiceInOperationsMenu) {
							case 1: 
								System.out.println();
								System.out.print("Enter the file name to be added along with its extension: ");
								fileName = s.next();
								addFile.addNewFile(fileName);
							break;
							
							case 2:
								System.out.println();
								System.out.print("Enter the file name to be deleted along with its extension: ");
								fileName = s.next();
								deleteFile.deleteFileFromDirectory(fileName);
							break;
							
							case 3:
								System.out.println();
								System.out.print("Enter the file name that you are looking for along with its extension: ");
								fileName = s.next();
								searchFile.searchFileName(fileName);
							break;
							
							case 4:
								System.out.println();
								System.out.println("Returning back to main menu.");
							break;
							
							default:
								System.out.println("You entered a wrong choice, please choose from the available options.");
							break;
							
						}
					}while(choiceInOperationsMenu != 4);
					
				case 3: 
					System.out.println();
					System.out.println("Thank you.");
				break;
				
				default:
					System.out.println("You entered a wrong choice, please choose from the available options.");
				break;
			}		
			
		}while(choiceInMainMenu != 3);
		}catch(InputMismatchException e) {
			System.out.println("Error, you entered an alphabetic character, please enter a number.");
		}
		s.close();
	}

}
