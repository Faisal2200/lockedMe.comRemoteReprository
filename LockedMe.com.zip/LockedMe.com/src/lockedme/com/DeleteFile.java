package lockedme.com;

import java.io.File;

public class DeleteFile {
	
	public void deleteFileFromDirectory(String fileName) {
		try {
			
			File file = new File("C:/MyDirectory/"+fileName);
			
			if(file.delete()) {
				System.out.println(file.getName()+" has been deleted.");
			}else {
				System.out.println("File not found.");
			}
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
	
}
