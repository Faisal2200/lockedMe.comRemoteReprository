package lockedme.com;

import java.io.File;
import java.io.IOException;

public class AddFile {
	
	private String fileName;
	
	public void addNewFile(String fileName) {
		try {
			
			File file = new File("C:/MyDirectory/"+fileName);
			
			if(file.createNewFile()) {
				System.out.println("File added successfully.");
			}else {
				System.out.println("File already exists.");
			}
		}catch(IOException e) {
			e.printStackTrace();
		}
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

}
