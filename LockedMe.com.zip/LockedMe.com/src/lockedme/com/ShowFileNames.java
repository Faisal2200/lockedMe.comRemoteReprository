package lockedme.com;

import java.io.File;

public class ShowFileNames {
	
	public void getFileNames() {
		try {
			
			File directory = new File("C:/MyDirectory");
			File[] allFileNames = directory.listFiles();
			String[] fileNames = new String[allFileNames.length];
			
			//File names are sorted using insertion sort algorithm.
			
			for(int count = 0; count < allFileNames.length; count++) {
				fileNames[count] = allFileNames[count].getName();
			}
				
			for(int firstUnsortedIndex = 1; firstUnsortedIndex < fileNames.length; firstUnsortedIndex++) {
				String newElement = fileNames[firstUnsortedIndex];
				
				int i;
				for(i = firstUnsortedIndex; i > 0 && fileNames[i-1].compareTo(newElement) > 0; i--) {
						fileNames[i] = fileNames[i-1];
				}
				
				fileNames[i] = newElement;
			}
			for(int j = 0; j < fileNames.length; j++) {
				System.out.println(fileNames[j]);
			}
			
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
	
}
