package lockedme.com;

import java.io.File;

public class SearchFile {
	
	public void searchFileName(String fileName) {
		try {
			File directory = new File("C:/MyDirectory");
			File[] allFileNames = directory.listFiles();
			boolean found = false;
			
			//Linear search is used to search for a file.
			
			for(int i = 0; i < allFileNames.length; i++) {
				
				if(allFileNames[i].getName().equals(fileName)) {
					found = true;
					break;
				}
				
			}
			
			if(found == true) {
				System.out.println(fileName+" has been successfully found in the directory.");
			}else {
				System.out.println(fileName+" was not found in the directory.");
			}
		}catch(Exception e) {
			e.printStackTrace();
		}
		
	}
	
}
